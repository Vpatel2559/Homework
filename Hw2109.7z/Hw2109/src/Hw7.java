public class Hw7 {
    public static void main(String args[])
    {
        String str = "hello@world";
        String[] arrOfStr = str.split("@", -2);

        for (String a : arrOfStr)
            System.out.println(a);
    }
}
